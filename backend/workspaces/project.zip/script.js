<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Responsive Calendar</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  :root {
    --primary:#2563eb;
    --bg:#f8fafc;
    --radius:12px;
    --shadow:0 2px 8px rgba(0,0,0,0.1);
    --font-base:1rem;
    --font-lg:1.5rem;
    --font-sm:.875rem;
  }
  *{box-sizing:border-box;margin:0;padding:0;}
  body{
    font-family:system-ui,Arial,sans-serif;
    background:var(--bg);
    color:#111;
    line-height:1.5;
    padding:2rem;
    display:flex;
    justify-content:center;
    align-items:flex-start;
  }
  .calendar{
    background:#fff;
    border-radius:var(--radius);
    box-shadow:var(--shadow);
    max-width:420px;
    width:100%;
    padding:1.5rem;
    display:flex;
    flex-direction:column;
    gap:1rem;
  }
  .header{
    display:flex;
    justify-content:space-between;
    align-items:center;
  }
  .header h2{
    font-size:var(--font-lg);
    font-weight:600;
  }
  .nav-btn{
    background:transparent;
    border:none;
    color:var(--primary);
    font-size:var(--font-lg);
    cursor:pointer;
    transition:color .2s;
  }
  .nav-btn:hover{
    color:#1e40af;
  }
  #calendar-grid{
    display:grid;
    grid-template-columns:repeat(7,1fr);
    gap:0.5rem;
  }
  .day-name{
    font-size:var(--font-sm);
    text-align:center;
    font-weight:600;
    color:#555;
  }
  .date-cell{
    width:100%;
    padding-top:100%;
    position:relative;
    background:#f1f5f9;
    border-radius:var(--radius);
    cursor:pointer;
    transition:background .2s,transform .2s;
  }
  .date-cell:hover{
    background:#e2e8f0;
    transform:scale(1.03);
  }
  .date-cell span{
    position:absolute;
    top:50%;left:50%;
    transform:translate(-50%,-50%);
    font-size:var(--font-base);
  }
  .today{
    background:var(--primary);
    color:#fff;
  }
  @media (max-width:480px){
    .calendar{padding:1rem;}
    .header h2{font-size:1.25rem;}
    .nav-btn{font-size:1.25rem;}
  }
</style>
</head>
<body>
<div class="calendar">
  <div class="header">
    <button class="nav-btn" id="prev-btn">&#9664;</button>
    <h2 id="month-year"></h2>
    <button class="nav-btn" id="next-btn">&#9654;</button>
  </div>
  <div id="calendar-grid"></div>
</div>

<script>
  const MONTHS = [
    "January","February","March","April","May","June",
    "July","August","September","October","November","December"
  ];
  const WEEKDAYS = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];

  const calendarGrid = document.getElementById('calendar-grid');
  const monthYearLabel = document.getElementById('month-year');
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');

  let currentMonth;
  let currentYear;

  function renderCalendar(month, year){
    calendarGrid.innerHTML = "";
    monthYearLabel.textContent = `${MONTHS[month]} ${year}`;

    // render weekday names
    WEEKDAYS.forEach(d => {
      const div = document.createElement('div');
      div.className = "day-name";
      div.textContent = d;
      calendarGrid.appendChild(div);
    });

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // fill blanks before first day
    for(let i=0;i<firstDay;i++){
      const blank = document.createElement('div');
      calendarGrid.appendChild(blank);
    }

    const today = new Date();
    const isCurrentYear = today.getFullYear() === year;

    for(let date=1; date<=daysInMonth; date++){
      const cell = document.createElement('div');
      cell.className = "date-cell";
      const span = document.createElement('span');
      span.textContent = date;
      cell.appendChild(span);

      if(isCurrentYear && today.getMonth()===month && today.getDate()===date){
        cell.classList.add('today');
      }

      calendarGrid.appendChild(cell);
    }
  }

  function changeMonth(delta){
    currentMonth += delta;
    if(currentMonth < 0){
      currentMonth = 11;
      currentYear--;
    } else if(currentMonth > 11){
      currentMonth = 0;
      currentYear++;
    }
    renderCalendar(currentMonth, currentYear);
  }

  prevBtn.addEventListener('click',()=>changeMonth(-1));
  nextBtn.addEventListener('click',()=>changeMonth(1));

  // Initialize
  (function init(){
    const now = new Date();
    currentYear = 2026;
    if(now.getFullYear()===2026){
      currentMonth = now.getMonth();
    } else {
      currentMonth = 0; // January
    }
    renderCalendar(currentMonth, currentYear);
  })();
</script>
</body>
</html>